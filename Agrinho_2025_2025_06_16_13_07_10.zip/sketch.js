const startButton = document.getElementById("start-btn");

// Função para iniciar a festa
startButton.addEventListener("click", function() {
  // Troca de tela para uma nova "festa"
  window.location.href = "quiz.html";
});


function sendMessage(message) {
  const messageBox = document.getElementById("message-box");
  const newMessage = document.createElement("div");
  newMessage.classList.add("message");
  newMessage.innerText = message;
  messageBox.appendChild(newMessage);
}
const quizQuestions = [
  {
    question: "Qual é o principal alimento produzido no campo?",
    options: ["Arroz", "Computadores", "Máquinas de café", "Carne de soja"],
    correctAnswer: "Arroz"
  },
  {
    question: "Qual é a principal atividade nas cidades?",
    options: ["Agricultura", "Indústria e Comércio", "Pecuária", "Pesca"],
    correctAnswer: "Indústria e Comércio"
  }
];

function startQuiz() {
  let score = 0;

  quizQuestions.forEach((question, index) => {
    const userAnswer = prompt(`${question.question}\n${question.options.join(", ")}`);
    if (userAnswer === question.correctAnswer) {
      score++;
    }
  });

  alert(`Você acertou ${score} de ${quizQuestions.length} perguntas!`);
}

